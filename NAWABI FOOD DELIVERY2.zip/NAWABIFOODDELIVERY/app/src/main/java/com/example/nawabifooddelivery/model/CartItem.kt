package com.example.nawabifooddelivery.model

data class CartItem(
    val dish: Dish,
    val selectedVariant: DishVariant,
    var quantity: Int = 1,
    var specialInstructions: String = ""
) {
    val unitPrice: Double
        get() = dish.getEffectivePrice(selectedVariant.id)

    val totalPrice: Double
        get() = unitPrice * quantity
}

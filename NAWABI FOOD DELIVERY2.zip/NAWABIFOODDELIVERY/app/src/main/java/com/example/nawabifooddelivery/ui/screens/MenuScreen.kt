package com.example.nawabifooddelivery.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.nawabifooddelivery.MainTab
import com.example.nawabifooddelivery.model.Dish
import com.example.nawabifooddelivery.model.DishVariant
import com.example.nawabifooddelivery.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MenuScreen(
    dishes: List<Dish>,
    selectedCategory: String,
    onSelectCategory: (String) -> Unit,
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    currentMainTab: MainTab,
    onMainTabChange: (MainTab) -> Unit,
    onAddToCart: (Dish, DishVariant) -> Unit,
    cartItemCount: Int,
    cartSubtotal: Double,
    onOpenCart: () -> Unit,
    onOpenRestaurantInfo: () -> Unit,
    onOpenAiAssistant: () -> Unit
) {
    val categories = remember(currentMainTab) {
        when (currentMainTab) {
            MainTab.NAWABI -> listOf(
                "all" to "Royal Menu",
                "royal_thals" to "👑 Grand Thals",
                "biryani_pulao" to "🍚 Dum Biryani",
                "starters_tandoori" to "🍢 Tandoor",
                "main_course" to "🍲 Gravies",
                "roti_breads" to "🫓 Bread",
                "desserts" to "🍮 Sweets"
            )
            MainTab.DRAGON -> listOf(
                "all" to "Dragon Express",
                "dragon_shawarma" to "🌯 Shawarma & Rolls"
            )
            MainTab.FULL -> listOf(
                "all" to "Full Menu",
                "royal_thals" to "👑 Thals",
                "biryani_pulao" to "🍚 Biryani",
                "starters_tandoori" to "🍢 Tandoor",
                "main_course" to "🍲 Gravies",
                "dragon_shawarma" to "🌯 Dragon",
                "roti_breads" to "🫓 Breads",
                "desserts" to "🍮 Sweets"
            )
        }
    }

    Scaffold(
        containerColor = NawabiCream,
        topBar = {
            Column(modifier = Modifier.background(Color.White)) {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                "NAWABI DASTARKHWAN",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                color = NawabiEmerald,
                                letterSpacing = 1.sp
                            )
                            Text(
                                "Govandi, Mumbai • Estd. 2005",
                                style = MaterialTheme.typography.labelSmall,
                                color = NawabiGold
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onOpenAiAssistant) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = "AI Assistant", tint = NawabiGold)
                        }
                    },
                    actions = {
                        IconButton(onClick = onOpenRestaurantInfo) {
                            Icon(Icons.Default.Info, contentDescription = "Info", tint = NawabiEmerald)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Color.White
                    )
                )

                TabRow(
                    selectedTabIndex = currentMainTab.ordinal,
                    containerColor = Color.White,
                    contentColor = NawabiEmerald,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[currentMainTab.ordinal]),
                            color = NawabiEmerald
                        )
                    },
                    divider = {}
                ) {
                    MainTab.entries.forEach { tab ->
                        Tab(
                            selected = currentMainTab == tab,
                            onClick = { onMainTabChange(tab) },
                            text = {
                                Text(
                                    text = when(tab) {
                                        MainTab.NAWABI -> "NAWABI"
                                        MainTab.DRAGON -> "DRAGON"
                                        MainTab.FULL -> "FULL MENU"
                                    },
                                    fontWeight = if (currentMainTab == tab) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp
                                )
                            }
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            AnimatedVisibility(
                visible = cartItemCount > 0,
                enter = scaleIn() + fadeIn(),
                exit = scaleOut() + fadeOut()
            ) {
                ExtendedFloatingActionButton(
                    onClick = onOpenCart,
                    containerColor = NawabiEmerald,
                    contentColor = Color.White,
                    shape = RoundedCornerShape(20.dp),
                    elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 10.dp)
                ) {
                    Icon(Icons.Default.ShoppingBag, contentDescription = null)
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            "$cartItemCount ITEMS",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "₹%.0f".format(cartSubtotal),
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                color = Color.White,
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 4.dp
            ) {
                TextField(
                    value = searchQuery,
                    onValueChange = onSearchQueryChange,
                    placeholder = { Text("Search biryani, kebabs, rolls...", color = NawabiGrey) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = NawabiGold) },
                    singleLine = true,
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Color.Transparent,
                        unfocusedContainerColor = Color.Transparent,
                        disabledContainerColor = Color.Transparent,
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(categories) { (catId, catName) ->
                    val isSelected = selectedCategory == catId
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectCategory(catId) },
                        label = { Text(catName, fontSize = 12.sp) },
                        shape = RoundedCornerShape(20.dp),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = NawabiGold,
                            selectedLabelColor = Color.White,
                            containerColor = Color.White,
                            labelColor = NawabiCharcoal
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = if (isSelected) Color.Transparent else Color.LightGray.copy(alpha = 0.5f),
                            selectedBorderColor = Color.Transparent,
                            borderWidth = 1.dp,
                            enabled = true,
                            selected = isSelected
                        )
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(dishes, key = { it.id }) { dish ->
                    AnimatedDishCard(
                        dish = dish,
                        onAddToCart = { variant -> onAddToCart(dish, variant) }
                    )
                }
            }
        }
    }
}

@Composable
fun AnimatedDishCard(
    dish: Dish,
    onAddToCart: (DishVariant) -> Unit
) {
    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { isVisible = true }

    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { 50 }) + fadeIn(animationSpec = tween(600)),
        exit = fadeOut()
    ) {
        PremiumDishCard(dish, onAddToCart)
    }
}

@Composable
fun PremiumDishCard(
    dish: Dish,
    onAddToCart: (DishVariant) -> Unit
) {
    var selectedVariant by remember(dish) {
        mutableStateOf(dish.variants.firstOrNull { it.isDefault } ?: dish.variants.firstOrNull() ?: DishVariant("default", "Standard", 0.0))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(elevation = 6.dp, shape = RoundedCornerShape(20.dp)),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            ) {
                AsyncImage(
                    model = dish.imageUrl,
                    contentDescription = dish.name,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Black.copy(alpha = 0.4f), Color.Transparent),
                                startY = 0f,
                                endY = 150f
                            )
                        )
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (dish.isSpecial) {
                            Surface(
                                color = NawabiGold,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text(
                                    "MUST TRY",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                        
                        Surface(
                            color = Color.White.copy(alpha = 0.9f),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, if (dish.isVeg) NawabiLightGreen else NawabiOrange)
                        ) {
                            Box(
                                modifier = Modifier.padding(4.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (dish.isVeg) NawabiLightGreen else NawabiOrange)
                                )
                            }
                        }
                    }

                    if (dish.discountPercent > 0) {
                        Surface(
                            color = NawabiOrange,
                            shape = CircleShape
                        ) {
                            Text(
                                "${dish.discountPercent}% OFF",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = dish.name,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = NawabiCharcoal
                        )
                        if (!dish.urduName.isNullOrBlank()) {
                            Text(
                                text = dish.urduName,
                                style = MaterialTheme.typography.labelMedium,
                                color = NawabiGold,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = NawabiGold, modifier = Modifier.size(18.dp))
                        Text(
                            " ${dish.rating}",
                            fontWeight = FontWeight.Bold,
                            color = NawabiCharcoal,
                            fontSize = 14.sp
                        )
                    }
                }

                Text(
                    text = dish.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = NawabiGrey,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                if (dish.variants.size > 1) {
                    Text(
                        "SELECT SIZE:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = NawabiGrey,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        dish.variants.forEach { variant ->
                            val isChosen = variant.id == selectedVariant.id
                            Surface(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { selectedVariant = variant },
                                color = if (isChosen) NawabiEmerald.copy(alpha = 0.1f) else NawabiCream,
                                shape = RoundedCornerShape(10.dp),
                                border = if (isChosen) BorderStroke(1.5.dp, NawabiEmerald) else null
                            ) {
                                Column(
                                    modifier = Modifier.padding(vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        variant.name,
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = if (isChosen) FontWeight.Bold else FontWeight.Medium,
                                        color = if (isChosen) NawabiEmerald else NawabiCharcoal
                                    )
                                    Text(
                                        "₹%.0f".format(variant.price),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = NawabiGrey
                                    )
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val effectivePrice = dish.getEffectivePrice(selectedVariant.id)
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "₹%.0f".format(effectivePrice),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Black,
                                color = NawabiCharcoal
                            )
                            if (effectivePrice < selectedVariant.price) {
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "₹%.0f".format(selectedVariant.price),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = NawabiGrey,
                                    textDecoration = TextDecoration.LineThrough
                                )
                            }
                        }
                        Text(
                            "Freshly prepared • ${dish.preparationMinutes}m",
                            style = MaterialTheme.typography.labelSmall,
                            color = NawabiLightGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = { onAddToCart(selectedVariant) },
                        colors = ButtonDefaults.buttonColors(containerColor = NawabiEmerald),
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp),
                        elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("ADD TO CART", fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
                    }
                }
            }
        }
    }
}

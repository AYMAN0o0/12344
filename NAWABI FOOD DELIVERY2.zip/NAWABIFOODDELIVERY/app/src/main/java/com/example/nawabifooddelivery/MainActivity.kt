package com.example.nawabifooddelivery

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.nawabifooddelivery.model.CartItem
import com.example.nawabifooddelivery.model.Dish
import com.example.nawabifooddelivery.model.RestaurantInfo
import com.example.nawabifooddelivery.service.WhatsAppDispatcher
import com.example.nawabifooddelivery.ui.screens.CartScreen
import com.example.nawabifooddelivery.ui.screens.FavoritesScreen
import com.example.nawabifooddelivery.ui.screens.HomeScreen
import com.example.nawabifooddelivery.ui.screens.MenuScreen
import com.example.nawabifooddelivery.ui.screens.ProfileScreen
import com.example.nawabifooddelivery.ui.theme.NAWABIFOODDELIVERYTheme
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            NAWABIFOODDELIVERYTheme {
                NawabiApp()
            }
        }
    }
}

@Composable
fun NawabiApp() {

    val app = androidx.compose.runtime.remember {
        null
    }

    val application = androidx.compose.ui.platform.LocalContext.current.applicationContext
            as NawabiApplication

    var screen by remember {
        mutableStateOf(AppScreen.HOME)
    }

    var currentMainTab by remember {
        mutableStateOf(MainTab.FULL)
    }

    var selectedCategory by remember {
        mutableStateOf("all")
    }

    var searchQuery by remember {
        mutableStateOf("")
    }

    var showRestaurantInfo by remember {
        mutableStateOf(false)
    }

    var dishes by remember {
        mutableStateOf<List<Dish>>(emptyList())
    }

    var cartItems by remember {
        mutableStateOf<List<CartItem>>(emptyList())
    }

    /*
     * Load menu from the existing repository.
     */
    LaunchedEffect(application) {
        application.menuRepository.allDishes.collectLatest {
            dishes = it
        }
    }

    /*
     * Main-tab filtering:
     *
     * NAWABI  = everything except Dragon Shawarma
     * DRAGON  = Dragon Shawarma
     * FULL    = complete menu
     */
    val filteredDishesByTab = remember(
        dishes,
        currentMainTab
    ) {
        when (currentMainTab) {

            MainTab.NAWABI -> {
                dishes.filter { dish ->
                    dish.category != "dragon_shawarma"
                }
            }

            MainTab.DRAGON -> {
                dishes.filter { dish ->
                    dish.category == "dragon_shawarma"
                }
            }

            MainTab.FULL -> {
                dishes
            }
        }
    }

    /*
     * Category + search filtering.
     */
    val visibleDishes = remember(
        filteredDishesByTab,
        selectedCategory,
        searchQuery
    ) {

        filteredDishesByTab.filter { dish ->

            val categoryMatches =
                selectedCategory == "all" ||
                        dish.category == selectedCategory

            val searchMatches =
                searchQuery.isBlank() ||
                        dish.name.contains(
                            searchQuery,
                            ignoreCase = true
                        ) ||
                        dish.description.contains(
                            searchQuery,
                            ignoreCase = true
                        ) ||
                        dish.tags.any {
                            it.contains(
                                searchQuery,
                                ignoreCase = true
                            )
                        }

            categoryMatches && searchMatches
        }
    }

    val cartCount = cartItems.sumOf {
        it.quantity
    }

    val cartSubtotal = cartItems.sumOf {
        it.totalPrice
    }

    /*
     * Add item to cart.
     */
    fun addToCart(
        dish: Dish,
        variant: Dish.Variant
    ) {

        val existingIndex = cartItems.indexOfFirst {
            it.dish.id == dish.id &&
                    it.selectedVariant.id == variant.id
        }

        cartItems =
            if (existingIndex >= 0) {

                cartItems.mapIndexed { index, item ->

                    if (index == existingIndex) {
                        item.copy(
                            quantity = item.quantity + 1
                        )
                    } else {
                        item
                    }
                }

            } else {

                cartItems + CartItem(
                    dish = dish,
                    selectedVariant = variant,
                    quantity = 1
                )
            }
    }

    /*
     * Update cart quantity.
     */
    fun updateQuantity(
        index: Int,
        quantity: Int
    ) {

        if (index !in cartItems.indices) {
            return
        }

        cartItems =
            if (quantity <= 0) {

                cartItems.filterIndexed { i, _ ->
                    i != index
                }

            } else {

                cartItems.mapIndexed { i, item ->

                    if (i == index) {
                        item.copy(
                            quantity = quantity
                        )
                    } else {
                        item
                    }
                }
            }
    }

    /*
     * Remove cart item.
     */
    fun removeItem(index: Int) {

        if (index !in cartItems.indices) {
            return
        }

        cartItems =
            cartItems.filterIndexed { i, _ ->
                i != index
            }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),

        bottomBar = {

            NavigationBar {

                NavigationBarItem(
                    selected = screen == AppScreen.HOME,
                    onClick = {
                        screen = AppScreen.HOME
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = {
                        Text("HOME")
                    }
                )

                NavigationBarItem(
                    selected = screen == AppScreen.MENU,
                    onClick = {
                        screen = AppScreen.MENU
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Menu"
                        )
                    },
                    label = {
                        Text("MENU")
                    }
                )

                NavigationBarItem(
                    selected = screen == AppScreen.CART,
                    onClick = {
                        screen = AppScreen.CART
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.ShoppingCart,
                            contentDescription = "Cart"
                        )
                    },
                    label = {
                        Text(
                            if (cartCount > 0) {
                                "CART $cartCount"
                            } else {
                                "CART"
                            }
                        )
                    }
                )

                NavigationBarItem(
                    selected = screen == AppScreen.FAVORITES,
                    onClick = {
                        screen = AppScreen.FAVORITES
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Favorite,
                            contentDescription = "Favorites"
                        )
                    },
                    label = {
                        Text("FAVORITES")
                    }
                )

                NavigationBarItem(
                    selected = screen == AppScreen.PROFILE,
                    onClick = {
                        screen = AppScreen.PROFILE
                    },
                    icon = {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Profile"
                        )
                    },
                    label = {
                        Text("PROFILE")
                    }
                )
            }
        }
    ) { paddingValues ->

        when (screen) {

            AppScreen.HOME -> {

                HomeScreen(
                    dishes = dishes,
                    onNavigateToMenu = {
                        screen = AppScreen.MENU
                    },
                    onOpenRestaurantInfo = {
                        showRestaurantInfo = true
                    },
                    onOpenAiAssistant = {
                        screen = AppScreen.AI
                    },
                    onAddToCart = { dish, variant ->
                        addToCart(dish, variant)
                    }
                )
            }

            AppScreen.MENU -> {

                MenuScreen(
                    dishes = visibleDishes,
                    selectedCategory = selectedCategory,
                    onSelectCategory = {
                        selectedCategory = it
                    },
                    searchQuery = searchQuery,
                    onSearchQueryChange = {
                        searchQuery = it
                    },
                    currentMainTab = currentMainTab,
                    onMainTabChange = {
                        currentMainTab = it
                        selectedCategory = "all"
                    },
                    onAddToCart = { dish, variant ->
                        addToCart(dish, variant)
                    },
                    cartItemCount = cartCount,
                    cartSubtotal = cartSubtotal,
                    onOpenCart = {
                        screen = AppScreen.CART
                    },
                    onOpenRestaurantInfo = {
                        showRestaurantInfo = true
                    },
                    onOpenAiAssistant = {
                        screen = AppScreen.AI
                    }
                )
            }

            AppScreen.CART -> {

                CartScreen(
                    cartItems = cartItems,
                    onUpdateQuantity = { index, quantity ->
                        updateQuantity(index, quantity)
                    },
                    onRemoveItem = { index ->
                        removeItem(index)
                    },
                    onCloseCart = {
                        screen = AppScreen.MENU
                    },
                    onCheckoutViaWhatsApp = {

                        /*
                         * Keep existing order / WhatsApp flow.
                         */
                        val order = application.createOrderFromCart(
                            cartItems
                        )

                        application.saveOrder(order)

                        WhatsAppDispatcher.dispatchOrder(
                            application,
                            order
                        )
                    }
                )
            }

            AppScreen.FAVORITES -> {

                FavoritesScreen(
                    dishes = dishes,
                    onAddToCart = { dish, variant ->
                        addToCart(dish, variant)
                    }
                )
            }

            AppScreen.PROFILE -> {

                ProfileScreen(
                    onOpenRestaurantInfo = {
                        showRestaurantInfo = true
                    },
                    onOpenAiAssistant = {
                        screen = AppScreen.AI
                    }
                )
            }

            AppScreen.AI -> {

                AiAssistantScreen(
                    onBack = {
                        screen = AppScreen.HOME
                    },
                    menuContext = dishes.joinToString(
                        separator = "\n"
                    ) { dish ->

                        buildString {

                            append(dish.name)

                            if (dish.description.isNotBlank()) {
                                append(" - ")
                                append(dish.description)
                            }

                            if (dish.variants.isNotEmpty()) {
                                append(" | ")

                                append(
                                    dish.variants.joinToString {
                                            variant ->
                                        "${variant.name}: ${
                                            dish.getEffectivePrice(
                                                variant.id
                                            )
                                        }"
                                    }
                                )
                            }
                        }
                    }
                )
            }
        }
    }

    /*
     * Restaurant information dialog.
     */
    if (showRestaurantInfo) {

        val restaurant = RestaurantInfo.OFFICIAL

        AlertDialog(
            onDismissRequest = {
                showRestaurantInfo = false
            },

            title = {
                Text(restaurant.name)
            },

            text = {

                Text(
                    buildString {

                        appendLine(restaurant.tagline)
                        appendLine()
                        appendLine(restaurant.address)
                        appendLine()
                        appendLine(
                            "Delivery: ${restaurant.deliveryHotline1}"
                        )
                        appendLine(
                            "Delivery: ${restaurant.deliveryHotline2}"
                        )
                        appendLine()
                        appendLine(
                            "Opening Hours: ${restaurant.openingHours}"
                        )

                        if (
                            restaurant.fridayPrayerNotice
                                .isNotBlank()
                        ) {
                            appendLine()
                            appendLine(
                                restaurant.fridayPrayerNotice
                            )
                        }

                        if (restaurant.halalCertified) {
                            appendLine()
                            appendLine("✓ Halal Certified")
                        }
                    }
                )
            },

            confirmButton = {

                TextButton(
                    onClick = {
                        showRestaurantInfo = false
                    }
                ) {
                    Text("CLOSE")
                }
            }
        )
    }
}
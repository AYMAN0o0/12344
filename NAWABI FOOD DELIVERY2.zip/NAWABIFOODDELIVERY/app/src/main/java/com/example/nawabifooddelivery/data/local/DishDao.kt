package com.example.nawabifooddelivery.data.local

import androidx.room.*
import com.example.nawabifooddelivery.model.Dish
import kotlinx.coroutines.flow.Flow

@Dao
interface DishDao {
    @Query("SELECT * FROM dishes WHERE isAvailable = 1 ORDER BY isSpecial DESC, name ASC")
    fun getAllAvailableDishes(): Flow<List<Dish>>

    @Query("SELECT * FROM dishes WHERE category = :category AND isAvailable = 1")
    fun getDishesByCategory(category: String): Flow<List<Dish>>

    @Query("SELECT * FROM dishes WHERE id = :dishId LIMIT 1")
    suspend fun getDishById(dishId: String): Dish?

    @Query("SELECT * FROM dishes WHERE name LIKE '%' || :query || '%' OR description LIKE '%' || :query || '%'")
    fun searchDishes(query: String): Flow<List<Dish>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(dishes: List<Dish>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(dish: Dish)

    @Update
    suspend fun update(dish: Dish)

    @Delete
    suspend fun delete(dish: Dish)

    @Query("DELETE FROM dishes")
    suspend fun clearAll()
}

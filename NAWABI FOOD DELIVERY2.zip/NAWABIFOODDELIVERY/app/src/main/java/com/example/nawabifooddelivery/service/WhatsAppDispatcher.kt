package com.example.nawabifooddelivery.service

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import com.example.nawabifooddelivery.model.Order
import com.example.nawabifooddelivery.model.RestaurantInfo
import java.net.URLEncoder

object WhatsAppDispatcher {

    private const val OFFICIAL_PHONE_CLEAN = "919582777222" // +91 9582 777 222
    private const val BACKUP_PHONE_CLEAN = "919583777222"   // +91 9583 777 222

    /**
     * Dispatches customer order to the official Nawabi Dastarkhwan WhatsApp hotline
     * using strictly deterministic application logic.
     */
    fun dispatchOrder(context: Context, order: Order, useBackupPhone: Boolean = false) {
        val targetPhone = if (useBackupPhone) BACKUP_PHONE_CLEAN else OFFICIAL_PHONE_CLEAN

        val message = buildOrderMessage(order)
        sendViaWhatsApp(context, targetPhone, message)
    }

    /**
     * Builds clean, professional, deterministic order summary for kitchen dispatch
     */
    fun buildOrderMessage(order: Order): String {
        val sb = StringBuilder()
        sb.appendLine("👑 *NAWABI DASTARKHWAN — NEW ORDER*")
        sb.appendLine("📍 *Family Restaurant & Banquet Hall (Govandi, Mumbai)*")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("🆔 *Order ID:* #${order.orderId}")
        sb.appendLine("👤 *Customer Name:* ${order.customerName}")
        sb.appendLine("📞 *Contact Number:* ${order.customerPhone}")
        sb.appendLine("🏠 *Delivery Address:* ${order.deliveryAddress}")
        sb.appendLine("💳 *Payment:* ${order.paymentMethod}")
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("🍽️ *ORDERED ITEMS:*")

        order.items.forEachIndexed { index, item ->
            val itemTotal = "₹%.0f".format(item.totalPrice)
            val unitPrice = "₹%.0f".format(item.unitPrice)
            sb.appendLine("${index + 1}. *${item.dishName}* (${item.variantName})")
            sb.appendLine("   ↳ Qty: ${item.quantity} × $unitPrice = $itemTotal")
        }

        sb.appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━")
        sb.appendLine("Subtotal: ₹%.0f".format(order.subtotal))
        if (order.discount > 0) {
            sb.appendLine("Discount: -₹%.0f".format(order.discount))
        }
        sb.appendLine("Delivery Charge: ₹%.0f".format(order.deliveryFee))
        sb.appendLine("🔥 *GRAND TOTAL: ₹%.0f*".format(order.grandTotal))
        sb.appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━")

        if (!order.notes.isNullOrBlank()) {
            sb.appendLine("📝 *Special Kitchen Note:* ${order.notes}")
            sb.appendLine("━━━━━━━━━━━━━━━━━━━━━━━━━")
        }

        sb.appendLine("✅ *100% Halal Certified • Fresh Coal Dum*")
        sb.appendLine("👨‍💻 *App Developed By:* Khalil Shaikh (+91- 86 91 81 29 39)")

        return sb.toString()
    }

    /**
     * Launches WhatsApp with pre-filled message using standard Android Intents
     */
    private fun sendViaWhatsApp(context: Context, phone: String, message: String) {
        try {
            val encodedMessage = URLEncoder.encode(message, "UTF-8")
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$phone&text=$encodedMessage")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(
                context,
                "Could not launch WhatsApp. Please check if WhatsApp is installed.",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

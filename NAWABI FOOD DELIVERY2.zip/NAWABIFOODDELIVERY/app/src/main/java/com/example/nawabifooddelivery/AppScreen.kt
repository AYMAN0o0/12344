package com.example.nawabifooddelivery

enum class AppScreen {
    HOME,
    MENU,
    CART,
    FAVORITES,
    PROFILE,
    AI
}

enum class MainTab {
    NAWABI,
    DRAGON,
    FULL
}
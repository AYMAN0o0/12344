package com.example.nawabifooddelivery.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.nawabifooddelivery.model.Dish
import com.example.nawabifooddelivery.model.DishVariant
import com.example.nawabifooddelivery.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    dishes: List<Dish>,
    onNavigateToMenu: () -> Unit,
    onOpenRestaurantInfo: () -> Unit,
    onOpenAiAssistant: () -> Unit,
    onAddToCart: (Dish, DishVariant) -> Unit
) {
    val specialDishes = remember(dishes) {
        dishes.filter { it.isSpecial }.ifEmpty { dishes }
    }

    Scaffold(
        containerColor = NawabiCream,
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("NAWABI DASTARKHWAN", fontWeight = FontWeight.ExtraBold, color = NawabiEmerald, letterSpacing = 1.sp, fontSize = 16.sp)
                        Text("Govandi, Mumbai", style = MaterialTheme.typography.labelSmall, color = NawabiGold)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onOpenAiAssistant) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "AI", tint = NawabiGold)
                    }
                },
                actions = {
                    IconButton(onClick = onOpenRestaurantInfo) {
                        Icon(Icons.Default.Info, contentDescription = "Info", tint = NawabiEmerald)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Promo Banner
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = NawabiGold.copy(alpha = 0.15f)),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(NawabiGold), contentAlignment = Alignment.Center) {
                            Text("15%", color = Color.White, fontWeight = FontWeight.Black)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text("👑 GRAND ROYAL THALS 15% OFF", fontWeight = FontWeight.Bold, color = NawabiEmerald, fontSize = 14.sp)
                            Text("100% Halal Certified • Fresh Coal Dum Cooking", fontSize = 12.sp, color = NawabiCharcoal)
                        }
                    }
                }
            }

            // Quick Actions / Categories Title
            item {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Royal Chef's Specials", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NawabiCharcoal)
                    Text(
                        "View Full Menu",
                        color = NawabiEmerald,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.clickable { onNavigateToMenu() }
                    )
                }
            }

            // Horizontal Chef Specials
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                ) {
                    items(specialDishes) { dish ->
                        Card(
                            modifier = Modifier.width(220.dp).shadow(2.dp, RoundedCornerShape(16.dp)),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)
                        ) {
                            Column {
                                AsyncImage(
                                    model = dish.imageUrl,
                                    contentDescription = null,
                                    modifier = Modifier.fillMaxWidth().height(120.dp),
                                    contentScale = ContentScale.Crop
                                )
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(dish.name, fontWeight = FontWeight.Bold, maxLines = 1, color = NawabiCharcoal, fontSize = 14.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("₹%.0f".format(dish.getBasePrice()), fontWeight = FontWeight.ExtraBold, color = NawabiGold)
                                        Surface(
                                            onClick = {
                                                dish.variants.firstOrNull()?.let { onAddToCart(dish, it) }
                                            },
                                            color = NawabiEmerald,
                                            shape = RoundedCornerShape(8.dp)
                                        ) {
                                            Text("+ Add", color = Color.White, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quick Info Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("✨ Imperial Experience", fontWeight = FontWeight.Bold, color = NawabiEmerald)
                        Spacer(Modifier.height(8.dp))
                        Text("📍 Gajanan Colony, Govandi, Mumbai", fontSize = 13.sp, color = NawabiCharcoal)
                        Text("⏰ 12:00 PM – 05:00 AM (Late Night)", fontSize = 13.sp, color = NawabiCharcoal)
                        Text("📞 Hotlines: +91 9582 777 222", fontSize = 13.sp, color = NawabiCharcoal)
                    }
                }
            }
        }
    }
}

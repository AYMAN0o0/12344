package com.example.nawabifooddelivery.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.nawabifooddelivery.model.Dish
import com.example.nawabifooddelivery.model.DishVariant
import com.example.nawabifooddelivery.ui.theme.NawabiCharcoal
import com.example.nawabifooddelivery.ui.theme.NawabiCream
import com.example.nawabifooddelivery.ui.theme.NawabiEmerald
import com.example.nawabifooddelivery.ui.theme.NawabiGrey

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FavoritesScreen(
    dishes: List<Dish>,
    onAddToCart: (Dish, DishVariant) -> Unit
) {
    // For demo/production-ready UX, filter dishes marked as special or fallback to first few dishes
    val favoriteDishes = remember(dishes) {
        dishes.filter { it.isSpecial }.ifEmpty { dishes.take(3) }
    }

    Scaffold(
        containerColor = NawabiCream,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Your Royal Favorites", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        if (favoriteDishes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.FavoriteBorder,
                        contentDescription = null,
                        modifier = Modifier.size(72.dp),
                        tint = NawabiGrey.copy(alpha = 0.5f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("No favorites added yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NawabiCharcoal)
                    Text("Mark items as favorite to see them here.", style = MaterialTheme.typography.bodyMedium, color = NawabiGrey)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(favoriteDishes, key = { it.id }) { dish ->
                    PremiumDishCard(
                        dish = dish,
                        onAddToCart = { variant -> onAddToCart(dish, variant) }
                    )
                }
            }
        }
    }
}

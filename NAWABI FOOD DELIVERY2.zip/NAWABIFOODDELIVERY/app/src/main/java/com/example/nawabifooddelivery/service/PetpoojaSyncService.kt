package com.example.nawabifooddelivery.service

import com.example.nawabifooddelivery.model.Order

data class PetpoojaSyncResult(
    val success: Boolean,
    val petpoojaOrderId: String? = null,
    val message: String
)

/**
 * Petpooja integration boundary.
 *
 * This merged project deliberately does NOT fabricate a Petpooja order ID or claim
 * that a POS order was synchronized. Real credentials/API configuration must be
 * supplied through an approved backend integration in the next phase.
 */
object PetpoojaSyncService {

    suspend fun syncOrderToPetpooja(order: Order): PetpoojaSyncResult {
        return PetpoojaSyncResult(
            success = false,
            message = "Petpooja POS is not configured yet. Order #${order.orderId} remains available for WhatsApp dispatch."
        )
    }
}

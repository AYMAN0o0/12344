package com.example.nawabifooddelivery.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

enum class OrderStatus(val display: String, val colorHex: String) {
    RECEIVED("Order Received", "#D97706"),
    CONFIRMED("Kitchen Confirmed", "#F59E0B"),
    PREPARING("Coal Dum Cooking", "#059669"),
    OUT_FOR_DELIVERY("Out for Delivery", "#0284C7"),
    DELIVERED("Delivered", "#16A34A"),
    CANCELLED("Cancelled", "#DC2626")
}

data class OrderItemRecord(
    val dishId: String,
    val dishName: String,
    val variantName: String,
    val unitPrice: Double,
    val quantity: Int,
    val totalPrice: Double
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey
    val orderId: String,
    val customerName: String,
    val customerPhone: String,
    val deliveryAddress: String,
    val items: List<OrderItemRecord>,
    val subtotal: Double,
    val deliveryFee: Double = 30.0,
    val discount: Double = 0.0,
    val grandTotal: Double,
    val paymentMethod: String = "Cash on Delivery (COD)",
    val status: OrderStatus = OrderStatus.RECEIVED,
    val createdAt: Long = System.currentTimeMillis(),
    val petpoojaOrderId: String? = null,
    val petpoojaSynced: Boolean = false,
    val notes: String? = null
)

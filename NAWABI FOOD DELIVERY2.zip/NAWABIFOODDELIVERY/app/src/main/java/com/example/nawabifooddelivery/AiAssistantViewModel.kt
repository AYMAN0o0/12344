package com.example.nawabifooddelivery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Success(val text: String) : AiUiState
    data class Error(val message: String) : AiUiState
}

class AiAssistantViewModel : ViewModel() {
    private val _uiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    val uiState: StateFlow<AiUiState> = _uiState.asStateFlow()

    private val model = Firebase.ai.generativeModel(
        modelName = "gemini-flash-latest"
    )

    fun ask(question: String, menuContext: String = "") {
        val clean = question.trim()
        if (clean.isEmpty()) return
        _uiState.value = AiUiState.Loading
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val prompt = """
                    You are the official AI restaurant assistant for Nawabi Dastarkhwan,
                    a family restaurant in Govandi, Mumbai.
                    Help customers with restaurant information, menu questions, food choices,
                    variants, prices, ordering guidance and delivery/order guidance.
                    Use only information supplied in the app context when stating menu prices.
                    If a requested detail is not available in the app context, clearly say it
                    is not available instead of inventing it.
                    Keep answers concise and useful. You can reply in English, Hindi or Urdu
                    according to the customer's language.

                    Restaurant context:
                    Name: Nawabi Dastarkhwan Family Restaurant & Hall
                    Website: https://www.nawabidastarkhwan.com/
                    Location: Gajanan Colony, Plot No. 28/L/6, 7, Shivaji Nagar,
                    Near Jafari School, Govandi, Mumbai, Maharashtra 400043
                    Delivery hotlines: +91 9582 777 222, +91 9583 777 222
                    Opening hours: 12:00 PM (Noon) – 05:00 AM (Late Night)
                    Friday prayer closure: 12:30 PM – 2:00 PM
                    Halal certified: Yes
                    No beef policy: Yes

                    Current app menu context (use this as the source of truth for menu items and prices):
                    ${menuContext.ifBlank { "No live menu context is currently available." }}

                    Customer question:
                    $clean
                """.trimIndent()
                val response = model.generateContent(prompt)
                val output = response.text?.trim()
                if (!output.isNullOrEmpty()) {
                    _uiState.value = AiUiState.Success(output)
                } else {
                    _uiState.value = AiUiState.Error("The AI assistant returned no answer.")
                }
            } catch (e: Exception) {
                _uiState.value = AiUiState.Error(
                    e.localizedMessage ?: "Unable to contact the AI assistant."
                )
            }
        }
    }

    fun reset() {
        _uiState.value = AiUiState.Idle
    }
}

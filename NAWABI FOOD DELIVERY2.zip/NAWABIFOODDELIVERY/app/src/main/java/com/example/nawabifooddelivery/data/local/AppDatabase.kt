package com.example.nawabifooddelivery.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.example.nawabifooddelivery.model.Dish
import com.example.nawabifooddelivery.model.DishTypeConverters
import com.example.nawabifooddelivery.model.Order
import com.example.nawabifooddelivery.model.OrderItemRecord
import com.example.nawabifooddelivery.model.OrderStatus


class OrderStatusTypeConverter {
    @androidx.room.TypeConverter
    fun fromStatus(status: OrderStatus?): String? = status?.name

    @androidx.room.TypeConverter
    fun toStatus(value: String?): OrderStatus? = value?.let { runCatching { OrderStatus.valueOf(it) }.getOrNull() }
}

class OrderTypeConverters {
    private val gson = Gson()

    @androidx.room.TypeConverter
    fun fromOrderItemList(items: List<OrderItemRecord>?): String {
        return gson.toJson(items ?: emptyList<OrderItemRecord>())
    }

    @androidx.room.TypeConverter
    fun toOrderItemList(value: String?): List<OrderItemRecord> {
        if (value.isNullOrBlank()) return emptyList()
        val type = object : TypeToken<List<OrderItemRecord>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }
}

@Database(entities = [Dish::class, Order::class], version = 1, exportSchema = false)
@TypeConverters(DishTypeConverters::class, OrderTypeConverters::class, OrderStatusTypeConverter::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dishDao(): DishDao
    abstract fun orderDao(): OrderDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "nawabi_dastarkhwan_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

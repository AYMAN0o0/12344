package com.example.nawabifooddelivery.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nawabifooddelivery.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    onOpenRestaurantInfo: () -> Unit,
    onOpenAiAssistant: () -> Unit
) {
    Scaffold(
        containerColor = NawabiCream,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Royal Profile", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(16.dp))
            
            // Avatar Placeholder
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .clip(CircleShape)
                    .background(NawabiEmerald),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
            }
            
            Spacer(Modifier.height(12.dp))
            Text("Royal Guest", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = NawabiCharcoal)
            Text("100% Halal Certified Gastronomy", style = MaterialTheme.typography.bodyMedium, color = NawabiGold, fontWeight = FontWeight.Medium)
            
            Spacer(Modifier.height(32.dp))
            
            // Profile Options
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(elevation = 2.dp, shape = RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column {
                    ProfileOptionRow(icon = Icons.Default.Info, title = "Restaurant Location & Timing", onClick = onOpenRestaurantInfo)
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    ProfileOptionRow(icon = Icons.Default.AutoAwesome, title = "Chat with Nawabi AI", onClick = onOpenAiAssistant)
                    HorizontalDivider(color = Color.LightGray.copy(alpha = 0.3f))
                    ProfileOptionRow(icon = Icons.Default.Call, title = "Support Hotline (+91 9582 777 222)", onClick = {})
                }
            }
            
            Spacer(Modifier.weight(1f))
            
            Text(
                "Nawabi Dastarkhwan App v1.0",
                style = MaterialTheme.typography.labelSmall,
                color = NawabiGrey
            )
            Text(
                "Designed & Developed by Khalil Shaikh",
                style = MaterialTheme.typography.labelSmall,
                color = NawabiGrey,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(100.dp))
        }
    }
}

@Composable
private fun ProfileOptionRow(
    icon: ImageVector,
    title: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = NawabiEmerald, modifier = Modifier.size(24.dp))
            Spacer(Modifier.width(16.dp))
            Text(title, fontWeight = FontWeight.Medium, color = NawabiCharcoal, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = NawabiGrey, modifier = Modifier.size(20.dp))
        }
    }
}

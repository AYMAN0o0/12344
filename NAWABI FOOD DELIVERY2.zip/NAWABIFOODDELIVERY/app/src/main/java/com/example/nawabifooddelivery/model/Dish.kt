package com.example.nawabifooddelivery.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

enum class DishCategory(val id: String, val displayName: String, val icon: String) {
    ROYAL_THALS("royal_thals", "Grand Royal Thals (15% Off)", "crown"),
    BIRYANI_PULAO("biryani_pulao", "Dum Biryani & Rice", "bowl"),
    STARTERS_TANDOORI("starters_tandoori", "Charcoal Tandoor & Starters", "flame"),
    MAIN_COURSE("main_course", "Mughlai Gravies & Dastarkhwan", "pot"),
    DRAGON_SHAWARMA("dragon_shawarma", "Dragon Chinese & Shawarma", "utensils"),
    ROTI_BREADS("roti_breads", "Tandoori Roti & Naan", "wheat"),
    DESSERTS("desserts", "Royal Sweets & Beverages", "sparkles"),
    ALL("all", "Complete Royal Menu", "grid")
}

data class DishVariant(
    val id: String,
    val name: String, // e.g. "Half", "Full", "Special", "Plate", "Piece", "Person"
    val price: Double,
    val isDefault: Boolean = false,
    val discountPercent: Int = 0
)

@Entity(tableName = "dishes")
data class Dish(
    @PrimaryKey
    val id: String,
    val name: String,
    val urduName: String? = null,
    val description: String,
    val category: String,
    val categoryDisplayName: String,
    val variants: List<DishVariant>,
    val imageUrl: String,
    val isVeg: Boolean = false,
    val isSpicy: Boolean = false,
    val isSpecial: Boolean = false,
    val isAvailable: Boolean = true,
    val preparationMinutes: Int = 25,
    val servingSize: String = "1-2 Persons",
    val rating: Double = 4.9,
    val reviewCount: Int = 120,
    val discountPercent: Int = 0,
    val tags: List<String> = emptyList()
) {
    fun getBasePrice(): Double {
        val defaultVariant = variants.firstOrNull { it.isDefault } ?: variants.firstOrNull()
        return defaultVariant?.price ?: 0.0
    }

    fun getEffectivePrice(variantId: String? = null): Double {
        val variant = if (variantId != null) {
            variants.firstOrNull { it.id == variantId }
        } else {
            variants.firstOrNull { it.isDefault } ?: variants.firstOrNull()
        } ?: return 0.0

        val discount = if (variant.discountPercent > 0) variant.discountPercent else discountPercent
        return if (discount > 0) {
            variant.price * (1.0 - (discount.toDouble() / 100.0))
        } else {
            variant.price
        }
    }
}

class DishTypeConverters {
    private val gson = Gson()

    @TypeConverter
    fun fromVariantList(variants: List<DishVariant>?): String {
        return gson.toJson(variants ?: emptyList<DishVariant>())
    }

    @TypeConverter
    fun toVariantList(value: String?): List<DishVariant> {
        if (value.isNullOrBlank()) return emptyList()
        val type = object : TypeToken<List<DishVariant>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }

    @TypeConverter
    fun fromStringList(tags: List<String>?): String {
        return gson.toJson(tags ?: emptyList<String>())
    }

    @TypeConverter
    fun toStringList(value: String?): List<String> {
        if (value.isNullOrBlank()) return emptyList()
        val type = object : TypeToken<List<String>>() {}.type
        return gson.fromJson(value, type) ?: emptyList()
    }
}

package com.example.nawabifooddelivery.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.nawabifooddelivery.model.CartItem
import com.example.nawabifooddelivery.model.Order
import com.example.nawabifooddelivery.model.OrderItemRecord
import com.example.nawabifooddelivery.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(
    cartItems: List<CartItem>,
    onUpdateQuantity: (CartItem, Int) -> Unit,
    onRemoveItem: (CartItem) -> Unit,
    onCloseCart: () -> Unit,
    onCheckoutViaWhatsApp: (Order) -> Unit
) {
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }
    var specialNotes by remember { mutableStateOf("") }

    val subtotal = cartItems.sumOf { it.totalPrice }
    val deliveryFee = if (subtotal > 0) 30.0 else 0.0
    val grandTotal = subtotal + deliveryFee

    Scaffold(
        containerColor = NawabiCream,
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("Your Dastarkhwan Cart", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onCloseCart) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = NawabiEmerald)
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            if (cartItems.isNotEmpty()) {
                Surface(
                    shadowElevation = 12.dp,
                    color = Color.White,
                    shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Total Amount to Pay:", fontWeight = FontWeight.Bold, color = NawabiCharcoal, fontSize = 15.sp)
                            Text("₹%.0f".format(grandTotal), fontWeight = FontWeight.Black, fontSize = 22.sp, color = NawabiGold)
                        }

                        Spacer(Modifier.height(16.dp))

                        Button(
                            onClick = {
                                val order = Order(
                                    orderId = "${System.currentTimeMillis() % 1000000}",
                                    customerName = customerName.ifBlank { "Valued Guest" },
                                    customerPhone = customerPhone.ifBlank { "Not provided" },
                                    deliveryAddress = deliveryAddress.ifBlank { "Pickup at Govandi Restaurant" },
                                    items = cartItems.map {
                                        OrderItemRecord(
                                            dishId = it.dish.id,
                                            dishName = it.dish.name,
                                            variantName = it.selectedVariant.name,
                                            unitPrice = it.unitPrice,
                                            quantity = it.quantity,
                                            totalPrice = it.totalPrice
                                        )
                                    },
                                    subtotal = subtotal,
                                    deliveryFee = deliveryFee,
                                    grandTotal = grandTotal,
                                    notes = specialNotes
                                )
                                onCheckoutViaWhatsApp(order)
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = NawabiEmerald),
                            elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Text("Send Order via WhatsApp Hotline", fontWeight = FontWeight.Bold, fontSize = 15.sp, letterSpacing = 0.5.sp)
                        }

                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "App Design & Developed by Khalil Shaikh (+91- 86 91 81 29 39)",
                            style = MaterialTheme.typography.labelSmall,
                            color = NawabiGrey,
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        )
                    }
                }
            }
        }
    ) { padding ->
        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.ShoppingBag,
                        contentDescription = null,
                        modifier = Modifier.size(72.dp),
                        tint = NawabiGrey.copy(alpha = 0.5f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text("Your Dastarkhwan is empty", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = NawabiCharcoal)
                    Text("Explore our royal menu and add fresh delicacies.", style = MaterialTheme.typography.bodyMedium, color = NawabiGrey)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        "ITEMS SELECTED",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = NawabiGrey,
                        modifier = Modifier.padding(top = 16.dp, bottom = 4.dp)
                    )
                }

                items(cartItems) { item ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .shadow(elevation = 2.dp, shape = RoundedCornerShape(16.dp)),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.dish.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = NawabiCharcoal)
                                Text(
                                    "Size: ${item.selectedVariant.name} • ₹%.0f each".format(item.unitPrice),
                                    fontSize = 12.sp,
                                    color = NawabiGrey
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "₹%.0f".format(item.totalPrice),
                                    fontWeight = FontWeight.ExtraBold,
                                    color = NawabiGold,
                                    fontSize = 15.sp
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .background(NawabiCream, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 4.dp, vertical = 2.dp)
                            ) {
                                IconButton(
                                    onClick = {
                                        if (item.quantity > 1) onUpdateQuantity(item, item.quantity - 1)
                                        else onRemoveItem(item)
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Decrease", tint = NawabiEmerald)
                                }

                                Text(
                                    "${item.quantity}",
                                    fontWeight = FontWeight.Bold,
                                    color = NawabiCharcoal,
                                    modifier = Modifier.padding(horizontal = 8.dp),
                                    fontSize = 14.sp
                                )

                                IconButton(
                                    onClick = { onUpdateQuantity(item, item.quantity + 1) },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Increase", tint = NawabiEmerald)
                                }
                            }
                        }
                    }
                }

                item {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = Color.LightGray.copy(alpha = 0.5f))
                    Text(
                        "DELIVERY & CONTACT INFORMATION",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = NawabiGrey
                    )
                }

                item {
                    OutlinedTextField(
                        value = customerName,
                        onValueChange = { customerName = it },
                        label = { Text("Your Full Name") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NawabiEmerald,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("WhatsApp / Contact Number") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NawabiEmerald,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = deliveryAddress,
                        onValueChange = { deliveryAddress = it },
                        label = { Text("Delivery Address & Landmark (Mumbai)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NawabiEmerald,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                }

                item {
                    OutlinedTextField(
                        value = specialNotes,
                        onValueChange = { specialNotes = it },
                        label = { Text("Special Cooking Instructions / Note (Optional)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = NawabiEmerald,
                            unfocusedBorderColor = Color.LightGray
                        )
                    )
                }

                item {
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }
}

package com.example.nawabifooddelivery.ui.theme

import androidx.compose.ui.graphics.Color

val NawabiGold = Color(0xFFE5A93B)      // Premium appetizing gold
val NawabiEmerald = Color(0xFF1E5631)   // Dark royal appetizing green
val NawabiCream = Color(0xFFFFFDF9)     // Bright premium warm background
val NawabiCharcoal = Color(0xFF232323)  // Clean rich body/title text
val NawabiOrange = Color(0xFFE65100)    // Secondary highlight/accent color for non-veg / spice
val NawabiLightGreen = Color(0xFF4CAF50) // For veg indicator
val NawabiGrey = Color(0xFF757575)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

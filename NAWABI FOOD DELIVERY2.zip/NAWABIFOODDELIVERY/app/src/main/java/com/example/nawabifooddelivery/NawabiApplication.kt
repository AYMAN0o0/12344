package com.example.nawabifooddelivery

import android.app.Application
import com.example.nawabifooddelivery.data.local.AppDatabase
import com.example.nawabifooddelivery.data.repository.MenuRepository
import com.example.nawabifooddelivery.model.Order
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class NawabiApplication : Application() {

    internal val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val database by lazy { AppDatabase.getDatabase(this) }
    val menuRepository by lazy { MenuRepository(database.dishDao()) }

    override fun onCreate() {
        super.onCreate()
        // Seed the official menu on first startup.
        applicationScope.launch {
            runCatching { menuRepository.seedOfficialDishesIfEmpty() }
        }
    }

    fun saveOrder(order: Order) {
        applicationScope.launch {
            runCatching { database.orderDao().insertOrder(order) }
        }
    }
}

package com.example.nawabifooddelivery.data.repository

import com.example.nawabifooddelivery.data.local.DishDao
import com.example.nawabifooddelivery.model.Dish
import com.example.nawabifooddelivery.model.DishCategory
import com.example.nawabifooddelivery.model.DishVariant
import kotlinx.coroutines.flow.Flow

class MenuRepository(private val dishDao: DishDao) {

    val allDishes: Flow<List<Dish>> = dishDao.getAllAvailableDishes()

    fun getDishesByCategory(category: String): Flow<List<Dish>> {
        return if (category == "all") {
            dishDao.getAllAvailableDishes()
        } else {
            dishDao.getDishesByCategory(category)
        }
    }

    suspend fun getDishById(id: String): Dish? {
        return dishDao.getDishById(id)
    }

    suspend fun saveDish(dish: Dish) {
        dishDao.insert(dish)
    }

    suspend fun deleteDish(dish: Dish) {
        dishDao.delete(dish)
    }

    suspend fun seedOfficialDishesIfEmpty() {
        val count = dishDao.getDishById("thal_mutton_barbeque")
        if (count == null) {
            dishDao.insertAll(getOfficialPdfDishes())
        }
    }

    suspend fun restoreOfficialMenu() {
        dishDao.clearAll()
        dishDao.insertAll(getOfficialPdfDishes())
    }

    companion object {
        fun getOfficialPdfDishes(): List<Dish> {
            return listOf(
                // 1. GRAND ROYAL THALS & PLATTERS (15% OFF)
                Dish(
                    id = "thal_mutton_barbeque",
                    name = "Mutton Barbeque Thal",
                    urduName = "مٹن باربی کیو تھال",
                    description = "Royal celebration platter featuring juicy charcoal Mutton Seekh Kebabs, tender Mutton Boti, Galawati Kebabs, accompanied by aromatic Dum Rice, Roomali Roti, and fresh mint chutney.",
                    category = "royal_thals",
                    categoryDisplayName = "Grand Royal Thals (15% Off)",
                    variants = listOf(
                        DishVariant("thal_mut_bbq_4p", "4-5 Persons", 2200.0, discountPercent = 15),
                        DishVariant("thal_mut_bbq_8p", "8-10 Persons (Grand Royal)", 3800.0, isDefault = true, discountPercent = 15)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1544025162-d76694265947?w=800&auto=format&fit=crop&q=80",
                    isSpecial = true,
                    preparationMinutes = 35,
                    discountPercent = 15,
                    servingSize = "4-10 Persons"
                ),
                Dish(
                    id = "thal_chicken_barbeque",
                    name = "Chicken Barbeque Thal",
                    urduName = "چکن باربی کیو تھال",
                    description = "Signature Nawabi BBQ platter loaded with Chicken Tikka, Malai Tikka, Pahadi Tikka, Tandoori Tangdi, Chicken Seekh Kebabs, Roghani Naan, and saffron-infused Biryani Rice.",
                    category = "royal_thals",
                    categoryDisplayName = "Grand Royal Thals (15% Off)",
                    variants = listOf(
                        DishVariant("thal_chk_bbq_4p", "4-5 Persons", 1850.0, discountPercent = 15),
                        DishVariant("thal_chk_bbq_8p", "8-10 Persons (Grand Feast)", 3200.0, isDefault = true, discountPercent = 15)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&auto=format&fit=crop&q=80",
                    isSpecial = true,
                    preparationMinutes = 30,
                    discountPercent = 15,
                    servingSize = "4-10 Persons"
                ),
                Dish(
                    id = "thal_dastarkhwan_special",
                    name = "Dastarkhwan Royal Shahi Platter",
                    urduName = "دسترخوان رائل شاہی تھال",
                    description = "Our flagship feast combining Slow-Cooked Mutton Nihari, Chicken Dum Biryani, Mutton Galawati Kebabs, Tandoori Chicken, Mughlai Parathas, and Shahi Phirni.",
                    category = "royal_thals",
                    categoryDisplayName = "Grand Royal Thals (15% Off)",
                    variants = listOf(
                        DishVariant("thal_shahi_6p", "6-7 Persons", 2700.0, discountPercent = 15),
                        DishVariant("thal_shahi_10p", "10-12 Persons (Emperor Thal)", 4500.0, isDefault = true, discountPercent = 15)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?w=800&auto=format&fit=crop&q=80",
                    isSpecial = true,
                    preparationMinutes = 40,
                    discountPercent = 15,
                    servingSize = "6-12 Persons"
                ),

                // 2. DUM BIRYANI & RICE
                Dish(
                    id = "biryani_chicken_dum",
                    name = "Chicken Dum Biryani",
                    urduName = "چکن دم بریانی",
                    description = "Authentic Lucknowi style long-grain aged Basmati rice layered with fresh succulent chicken pieces, slow-cooked in a sealed clay handi over fragrant coal embers.",
                    category = "biryani_pulao",
                    categoryDisplayName = "Dum Biryani & Rice",
                    variants = listOf(
                        DishVariant("chk_dum_half", "Half", 170.0),
                        DishVariant("chk_dum_full", "Full", 290.0, isDefault = true),
                        DishVariant("chk_dum_spl", "Special (Extra Chicken)", 390.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=80",
                    isSpecial = true,
                    preparationMinutes = 20,
                    servingSize = "1-2 Persons"
                ),
                Dish(
                    id = "biryani_mutton_dum",
                    name = "Mutton Dum Biryani",
                    urduName = "مٹن دم بریانی",
                    description = "Mouth-melting tender goat mutton chunks marinated in yogurt, browned onions, saffron, and shahi garam masala, sealed under dough dum.",
                    category = "biryani_pulao",
                    categoryDisplayName = "Dum Biryani & Rice",
                    variants = listOf(
                        DishVariant("mut_dum_half", "Half", 240.0),
                        DishVariant("mut_dum_full", "Full", 420.0, isDefault = true),
                        DishVariant("mut_dum_spl", "Special Dum Handi", 560.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1633945274405-b6c8069047b0?w=800&auto=format&fit=crop&q=80",
                    isSpecial = true,
                    preparationMinutes = 25,
                    servingSize = "1-2 Persons"
                ),
                Dish(
                    id = "biryani_chicken_tikka",
                    name = "Chicken Tikka Biryani",
                    urduName = "چکن ٹکہ بریانی",
                    description = "Charcoal grilled boneless chicken tikka tossed in spicy tawa masala and folded into aromatic biryani rice.",
                    category = "biryani_pulao",
                    categoryDisplayName = "Dum Biryani & Rice",
                    variants = listOf(
                        DishVariant("chk_tikka_half", "Half", 190.0),
                        DishVariant("chk_tikka_full", "Full", 330.0, isDefault = true)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 20
                ),

                // 3. CHARCOAL TANDOOR & STARTERS
                Dish(
                    id = "tandoori_chicken",
                    name = "Tandoori Chicken",
                    urduName = "تندوری چکن",
                    description = "Whole chicken cut into juicy portions, marinated in mustard oil, Kashmiri deghi mirch, and hand-ground spices, roasted inside clay tandoor.",
                    category = "starters_tandoori",
                    categoryDisplayName = "Charcoal Tandoor & Starters",
                    variants = listOf(
                        DishVariant("tnd_chk_half", "Half (4 Pcs)", 220.0),
                        DishVariant("tnd_chk_full", "Full (8 Pcs)", 410.0, isDefault = true)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1599488615731-7e5c2823ff28?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 25
                ),
                Dish(
                    id = "chicken_seekh_kebab",
                    name = "Chicken Seekh Kebab",
                    urduName = "چکن سیخ کباب",
                    description = "Spiced minced chicken skewers grilled over red-hot charcoal, served with lemon wedges and mint dip.",
                    category = "starters_tandoori",
                    categoryDisplayName = "Charcoal Tandoor & Starters",
                    variants = listOf(
                        DishVariant("seekh_plate", "Plate (4 Pcs)", 230.0, isDefault = true),
                        DishVariant("seekh_special", "Special Butter Tossed", 280.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 20
                ),

                // 4. MUGHLAI GRAVIES
                Dish(
                    id = "mutton_nihari",
                    name = "Nawabi Mutton Nihari",
                    urduName = "نوابی مٹن نہاری",
                    description = "Overnight slow-simmered tender mutton shank gravy infused with bone marrow and 24 traditional herbs. Served with julienned ginger and green chilies.",
                    category = "main_course",
                    categoryDisplayName = "Mughlai Gravies & Dastarkhwan",
                    variants = listOf(
                        DishVariant("nihari_half", "Half", 260.0),
                        DishVariant("nihari_full", "Full", 460.0, isDefault = true),
                        DishVariant("nihari_nalli", "Special Nalli Nihari", 540.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1545247181-516773cae754?w=800&auto=format&fit=crop&q=80",
                    isSpecial = true,
                    preparationMinutes = 25
                ),
                Dish(
                    id = "butter_chicken",
                    name = "Murgh Makhani (Butter Chicken)",
                    urduName = "مرغ مکھنی",
                    description = "Shredded tandoori chicken cooked in a rich, buttery tomato cream gravy with dried fenugreek leaves (kasoori methi).",
                    category = "main_course",
                    categoryDisplayName = "Mughlai Gravies & Dastarkhwan",
                    variants = listOf(
                        DishVariant("butter_chk_half", "Half", 210.0),
                        DishVariant("butter_chk_full", "Full", 380.0, isDefault = true),
                        DishVariant("butter_chk_spl", "Special Boneless", 440.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1588166524941-3bf61a9c41db?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 20
                ),

                // 5. DRAGON CHINESE & SHAWARMA
                Dish(
                    id = "dragon_chicken_shawarma",
                    name = "Dragon Chicken Shawarma Roll",
                    urduName = "ڈریگن چکن شوارما",
                    description = "Freshly shaved juicy marinated chicken with garlic toum, pickled veggies, and fiery Dragon chili sauce wrapped in soft kuboos.",
                    category = "dragon_shawarma",
                    categoryDisplayName = "Dragon Chinese & Shawarma",
                    variants = listOf(
                        DishVariant("shw_regular", "Regular Roll", 120.0),
                        DishVariant("shw_cheese", "Cheese Burst Roll", 160.0, isDefault = true),
                        DishVariant("shw_open", "Open Plate Shawarma", 210.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1626777552726-4a6b54c97e46?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 12
                ),
                Dish(
                    id = "chicken_chilli_dry",
                    name = "Dragon Chicken Chilli",
                    urduName = "ڈریگن چکن چلی",
                    description = "Crispy batter fried chicken morsels tossed with fresh bell peppers, scallions, red chillies and dark soya in a high-flame wok.",
                    category = "dragon_shawarma",
                    categoryDisplayName = "Dragon Chinese & Shawarma",
                    variants = listOf(
                        DishVariant("chk_chilli_dry", "Dry (Starter)", 240.0, isDefault = true),
                        DishVariant("chk_chilli_gravy", "Gravy (Main Course)", 260.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1525755662778-989d0524087e?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 15
                ),

                // 6. ROTI & BREADS
                Dish(
                    id = "tandoori_roti",
                    name = "Tandoori Roti",
                    urduName = "تندوری روٹی",
                    description = "Crisp whole wheat flatbread baked against the piping hot clay walls of the tandoor.",
                    category = "roti_breads",
                    categoryDisplayName = "Tandoori Roti & Naan",
                    variants = listOf(
                        DishVariant("roti_plain", "Plain (1 Pc)", 20.0),
                        DishVariant("roti_butter", "Butter (1 Pc)", 25.0, isDefault = true)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1626074353765-517a681e40be?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 8
                ),
                Dish(
                    id = "butter_naan",
                    name = "Butter Naan / Garlic Naan",
                    urduName = "بٹر نان",
                    description = "Refined flour dough leavened and brushed with melted pure butter and crushed garlic.",
                    category = "roti_breads",
                    categoryDisplayName = "Tandoori Roti & Naan",
                    variants = listOf(
                        DishVariant("naan_butter", "Butter Naan", 45.0, isDefault = true),
                        DishVariant("naan_garlic", "Garlic Naan", 60.0),
                        DishVariant("naan_cheese", "Cheese Stuffed Naan", 90.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1601050690597-df0568f70950?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 8
                ),

                // 7. DESSERTS
                Dish(
                    id = "shahi_tukda",
                    name = "Shahi Tukda Royal",
                    urduName = "شاہی ٹکڑا",
                    description = "Ghee-fried bread soaked in saffron sugar syrup, topped with thick condensed rabdi, cardamom, and toasted pistachios.",
                    category = "desserts",
                    categoryDisplayName = "Royal Sweets & Beverages",
                    variants = listOf(
                        DishVariant("shahi_tukda_piece", "1 Portion", 90.0, isDefault = true),
                        DishVariant("shahi_tukda_double", "Double Rabdi Portion", 150.0)
                    ),
                    imageUrl = "https://images.unsplash.com/photo-1541832676-9b763b0239ab?w=800&auto=format&fit=crop&q=80",
                    preparationMinutes = 5
                )
            )
        }
    }
}

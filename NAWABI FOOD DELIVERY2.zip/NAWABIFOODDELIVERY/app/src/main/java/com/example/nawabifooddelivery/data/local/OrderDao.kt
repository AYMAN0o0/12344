package com.example.nawabifooddelivery.data.local

import androidx.room.*
import com.example.nawabifooddelivery.model.Order
import com.example.nawabifooddelivery.model.OrderStatus
import kotlinx.coroutines.flow.Flow

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE orderId = :orderId LIMIT 1")
    suspend fun getOrderById(orderId: String): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order)

    @Update
    suspend fun updateOrder(order: Order)

    @Query("UPDATE orders SET status = :status WHERE orderId = :orderId")
    suspend fun updateOrderStatus(orderId: String, status: OrderStatus)

    @Query("SELECT * FROM orders WHERE petpoojaSynced = 0")
    suspend fun getUnsyncedPetpoojaOrders(): List<Order>
}

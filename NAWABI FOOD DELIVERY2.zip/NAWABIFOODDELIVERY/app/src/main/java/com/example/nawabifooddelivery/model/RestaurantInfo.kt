package com.example.nawabifooddelivery.model

data class DeveloperCredit(
    val title: String = "APP DESIGN AND DEVELOPED BY.",
    val developerName: String = "KHALIL SHAIKH",
    val contactPhone: String = "+91- 86 91 81 29 39"
)

data class RestaurantInfo(
    val name: String = "Nawabi Dastarkhwan Family Restaurant & Hall",
    val urduName: String = "نوابی دسترخوان فیملی ریسٹورنٹ اینڈ ہال",
    val tagline: String = "Savor the Grand Heritage of Lucknowi & Mughlai Flavors",
    val establishedYear: Int = 2005,
    val address: String = "Gajanan Colony, Plot No. 28/L/6, 7, Shivaji Nagar, Near Jafari School, Govandi, Mumbai, Maharashtra 400043",
    val deliveryHotline1: String = "+91 9582 777 222",
    val deliveryHotline2: String = "+91 9583 777 222",
    val additionalHotline: String = "+91 7639 444 111",
    val dragonChineseHotline: String = "+91 7039 444 666",
    val officialWebsite: String = "https://www.nawabidastarkhwan.com/",
    val openingHours: String = "12:00 PM (Noon) – 05:00 AM (Late Night)",
    val fridayPrayerNotice: String = "Closed on Fridays from 12:30 PM – 2:00 PM for Jumma Namaz",
    val halalCertified: Boolean = true,
    val noBeefPolicy: Boolean = true,
    val hallCapacity: String = "A/C Banquet & Dastarkhwan Hall up to 100 Guests",
    val developerCredit: DeveloperCredit = DeveloperCredit()
) {
    companion object {
        val OFFICIAL = RestaurantInfo()
    }
}
